package pages.products;

import org.openqa.selenium.WebDriver;

// page_url = https://naveenautomationlabs.com/opencart/index.php?route=product/category&path=20
public class DesktopPage
{
    WebDriver driver;
    public DesktopPage(WebDriver driver)
    {
        this.driver = driver;
    }
}
