package pages.products;

import org.openqa.selenium.WebDriver;

// page_url = https://naveenautomationlabs.com/opencart/index.php?route=product/category&path=18
public class LaptopPage
{
    WebDriver driver;
    public LaptopPage(WebDriver driver)
    {
        this.driver = driver;
    }
}
