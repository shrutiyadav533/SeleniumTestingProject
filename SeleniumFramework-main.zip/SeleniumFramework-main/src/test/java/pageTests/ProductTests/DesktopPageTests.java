package pageTests.ProductTests;

public class DesktopPageTests {
}
