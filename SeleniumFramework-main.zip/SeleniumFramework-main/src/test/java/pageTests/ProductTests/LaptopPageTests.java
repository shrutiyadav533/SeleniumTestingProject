package pageTests.ProductTests;

public class LaptopPageTests {
}
